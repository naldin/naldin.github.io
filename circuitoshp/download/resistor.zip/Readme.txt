Para rodar Click 2 vezes em "VALUE"


	Resistor 1.03 from PROGRAM-ACTION
	=========================================
	A: 32 bits shareware for Windows95/98 and NT

This utility is for identification of electronic resitor value.
It will identify the color code to value or the value to color code.

This software need the VB5 run time files
available at this URL:
	ftp://ftp.simtel.net/pub/simtelnet/win95/dll/vb500b.zip

WEB SITE:	HTTP://WWW.CLIC.NET/~PROGRAMA