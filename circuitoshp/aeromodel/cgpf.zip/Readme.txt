
Os programas "Performance Factor (PF)" e "Centro de Gravidade (CG)" sao 
freeware e s�o de inteira responsabilidade do autor.

-----------------------------------------------------------------------------

Para o programa trabalhar, � necess�rio instalar os arquivos vbrum300.dll e 
ver.dll na pasta x:\windows\system ou na pasta em que se encontram os 
programas PF e CG.

Se voc� j� possue esses programas DLLs no seu computador, voc� pode deletar os 
que acompanha este programa.

Sistema requeridos:
Win 3.x or Win 95

-----------------------------------------------------------------------------

Se voc� tem alguma pergunta sobre os programas, envie email diretamente para
sebstrand@hotmail.com 

Voc� pode distribui-los livremente, mas n�o pode alterar o conte�do dos mesmos.


