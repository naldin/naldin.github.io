Chromatia Tuner, ReadMe file                      Copyr. 2001, FMJ-Software
---------------------------------------------------------------------------
This software is Shareware, see the REGISTER.TXT file for the details...

  The latest version of Chromatia is available for download on the internet
                                  @
                           www.fmjsoft.com
Requirements:

  - Windows 95, 98, ME, NT 3.51, NT 4.0 or 2000.
  - Mouse or equivalent pointing device.
  - A sound card.
  - Microsoft DirectX.

Installation:

  - Run SETUP.EXE and follow the instructions.
  - Read through the Help file.

NB: There's a few buggy video card drivers that can't handle the 'background
    texture' that this program use in dialogs. If it crashes during the 
    installation, try this: Click on the 'Start' button, select 'Run...', 
    type in 'Chromatia.exe -NOTEXTURE' and hit enter.

Uninstallation:

  - Use the Windows control panel's 'Add/Remove program' feature.

Distribution:

  - The program archive can be freely distributed provided that:
    1) It is not modified in any way whatsoever.
    2) It is clearly stated in accompanying text(s) that it is shareware.

Support:

  - Please see our www site, http://www.fmjsoft.com/
  - Be sure to review the F.A.Q. section of the program help file first!


Have Fun!
    __
   (\/)arkus of FMJ-Software
