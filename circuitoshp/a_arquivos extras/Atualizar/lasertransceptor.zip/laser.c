/****************************************************
**
**        Laser Pointer RS-232 Transceiver
**         Copyright (c) 1997 GKDesign
**         24th May 1997   George Katz
**         Data Transmitted @ 9600 bps
**
*****************************************************/

#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include <bios.h>
#include <stdio.h>

#define COM1       0
#define COM2       1
#define DATA_READY 0x100
#define TRUE       1
#define FALSE      0
#define ESC_KEY    '\x1b'

#define SETTINGS ( _COM_9600 | _COM_CHR8 | _COM_NOPARITY | _COM_STOP1)

void clear_line(int line)
{
    int i;

    gotoxy(1,line);     // clear a whole line
    for(i=0;i<80;i++)
        printf(" ");
}

int main(int argc, char *argv[])
{
   int in, out, status, done = FALSE;
   int curs_rx=0,curs_ry=15,curs_tx=0,curs_ty=4;
   int com_port=COM1;

   if (!(argc == 2 && (argv[1][0] == '2' || argv[1][0] == '1')))
   {
      printf("Usage: LASER [1|2]\nwhere 1 = Com port 1\n      2 = Com port 2\n");
      exit(-1);
   }

   if (argv[1][0]=='2') // select com port
      com_port = COM2;
   else
      com_port = COM1;

   bioscom(_COM_INIT, SETTINGS, com_port);    // Initialize serial port

   clrscr();
   printf("             GKDesign (c) 1997 Laser Transceiver Communicator V1.1\n");
   printf("                           Press [ESC] to exit program\n");
   printf("__________________________________ Sent Data ___________________________________");
   gotoxy(1,13);
   printf("________________________________ Recieved Data _________________________________");

   while (!done) {
      status = bioscom(_COM_STATUS, 0, com_port);   // recieved data?
      if (status & DATA_READY)
         if ((out = bioscom(_COM_RECEIVE, 0, com_port) & 0x7F) != 0)  {  // get data
            if (curs_rx < 78)         // move cursor
               curs_rx++;
            else {
                curs_rx = 1;          // at end of line
                if (curs_ry < 23)
                    curs_ry++;
                else
                    curs_ry = 15;

                clear_line(curs_ry);
            }
            gotoxy(curs_rx,curs_ry);  // goto correct screen location
            putch(out);               // print the character
         }

      if (kbhit())  {
          if ((in = getch()) == ESC_KEY) // check for ESC key
             done = TRUE;

          if(!in)                   // read an extended character
              in = getch();

          if (curs_tx < 78)         // position cursor
              curs_tx++;
          else   {
              curs_tx = 1;          // at end of line
              if (curs_ty < 12)
                  curs_ty++;
              else
                  curs_ty = 4;

              clear_line(curs_ty);
          }
          gotoxy(curs_tx,curs_ty);  // goto correct screen location
          putch(in);                // print the character
          bioscom(_COM_SEND, in, com_port); // output data
      }
   }
   clrscr();
   return (0);
}
