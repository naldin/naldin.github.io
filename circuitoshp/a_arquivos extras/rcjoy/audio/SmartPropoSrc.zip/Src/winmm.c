//---------------------------------------------------------------------------
#define _INC_MMSYSTEM

#include <windows.h>
#include <mmsystem.h>
#include <math.h>

#include "jr.h"
#include "futaba.h"

#define PW_FUTABA 6.623
#define PW_JR     7.340
#define PPM_MIN    30.0
#define PPM_MAX   100.0
#define PPM_TRIG    200

//#define FUTABA_PCM
//#define FUTABA_PPM
#define JR_PCM
//#define JR_PPM

#pragma argsused

#define MAXPNAMELEN      32     /* max product name length (including NULL) */
#define MAXERRORLENGTH   256    /* max error text length (including NULL) */
#define MAX_JOYSTICKOEMVXDNAME 260 /* max oem vxd name length (including NULL) */
#define JOYCAPS_HASV		0x0008
#define JOYERR_NOERROR        (0)                  /* no error */
#define JOYERR_BASE            160
#define JOYERR_UNPLUGGED      (JOYERR_BASE+7)      /* joystick is unplugged */
#define WAVERR_BASE            32
#define WAVERR_STILLPLAYING   (WAVERR_BASE + 1)    /* still something playing */
#define WIM_DATA              0x3C0
#define WAVE_FORMAT_PCM     1
#define WAVE_MAPPER     ((UINT)-1)
#define CALLBACK_FUNCTION   0x00030000l    /* dwCallback is a FARPROC */
DECLARE_HANDLE(HWAVEIN);

typedef struct {
    WORD        wFormatTag;         /* format type */
    WORD        nChannels;          /* number of channels (i.e. mono, stereo...) */
    DWORD       nSamplesPerSec;     /* sample rate */
    DWORD       nAvgBytesPerSec;    /* for buffer estimation */
    WORD        nBlockAlign;        /* block size of data */
    WORD        wBitsPerSample;     /* number of bits per sample of mono data */
    WORD        cbSize;             /* the count in bytes of the size of */
				    /* extra information (after cbSize) */
} WAVEFORMATEX;

typedef struct wavehdr_tag {
    LPSTR       lpData;                 /* pointer to locked data buffer */
    DWORD       dwBufferLength;         /* length of data buffer */
    DWORD       dwBytesRecorded;        /* used for input only */
    DWORD       dwUser;                 /* for client's use */
    DWORD       dwFlags;                /* assorted flags (see defines) */
    DWORD       dwLoops;                /* loop control counter */
    struct wavehdr_tag FAR *lpNext;     /* reserved for driver */
    DWORD       reserved;               /* reserved for driver */
} WAVEHDR;

static struct {
    char Path[MAX_PATH];
    HANDLE Handle;
    DWORD TlsIndex;
    void (*CloseDriver)(void);
    void (*DefDriverProc)(void);
    void (*DriverCallback)(void);
    void (*DrvGetModuleHandle)(void);
    void (*GetDriverModuleHandle)(void);
    void (*MigrateAllDrivers)(void);
    void (*MigrateMidiUser)(void);
    void (*MigrateSoundEvents)(void);
    void (*NotifyCallbackData)(void);
    void (*OpenDriver)(void);
    void (*PlaySound)(void);
    void (*PlaySoundA)(void);
    void (*PlaySoundW)(void);
    void (*SendDriverMessage)(void);
    void (*WOW32DriverCallback)(void);
    void (*WOW32ResolveMultiMediaHandle)(void);
    void (*WOWAppExit)(void);
    void (*WinmmLogoff)(void);
    void (*WinmmLogon)(void);
    void (*aux32Message)(void);
    void (*auxGetDevCapsA)(void);
    void (*auxGetDevCapsW)(void);
    void (*auxGetNumDevs)(void);
    void (*auxGetVolume)(void);
    void (*auxOutMessage)(void);
    void (*auxSetVolume)(void);
    void (*joy32Message)(void);
    void (*joyConfigChanged)(void);
    void (*joyGetDevCapsA)(void);
    void (*joyGetDevCapsW)(void);
    void (*joyGetNumDevs)(void);
    void (*joyGetPos)(void);
    void (*joyGetPosEx)(void);
    void (*joyGetThreshold)(void);
    void (*joyReleaseCapture)(void);
    void (*joySetCapture)(void);
    void (*joySetThreshold)(void);
    void (*mci32Message)(void);
    void (*mciDriverNotify)(void);
    void (*mciDriverYield)(void);
    void (*mciExecute)(void);
    void (*mciFreeCommandResource)(void);
    void (*mciGetCreatorTask)(void);
    void (*mciGetDeviceIDA)(void);
    void (*mciGetDeviceIDFromElementIDA)(void);
    void (*mciGetDeviceIDFromElementIDW)(void);
    void (*mciGetDeviceIDW)(void);
    void (*mciGetDriverData)(void);
    void (*mciGetErrorStringA)(void);
    void (*mciGetErrorStringW)(void);
    void (*mciGetYieldProc)(void);
    void (*mciLoadCommandResource)(void);
    void (*mciSendCommandA)(void);
    void (*mciSendCommandW)(void);
    void (*mciSendStringA)(void);
    void (*mciSendStringW)(void);
    void (*mciSetDriverData)(void);
    void (*mciSetYieldProc)(void);
    void (*mid32Message)(void);
    void (*midiConnect)(void);
    void (*midiDisconnect)(void);
    void (*midiInAddBuffer)(void);
    void (*midiInClose)(void);
    void (*midiInGetDevCapsA)(void);
    void (*midiInGetDevCapsW)(void);
    void (*midiInGetErrorTextA)(void);
    void (*midiInGetErrorTextW)(void);
    void (*midiInGetID)(void);
    void (*midiInGetNumDevs)(void);
    void (*midiInMessage)(void);
    void (*midiInOpen)(void);
    void (*midiInPrepareHeader)(void);
    void (*midiInReset)(void);
    void (*midiInStart)(void);
    void (*midiInStop)(void);
    void (*midiInUnprepareHeader)(void);
    void (*midiOutCacheDrumPatches)(void);
    void (*midiOutCachePatches)(void);
    void (*midiOutClose)(void);
    void (*midiOutGetDevCapsA)(void);
    void (*midiOutGetDevCapsW)(void);
    void (*midiOutGetErrorTextA)(void);
    void (*midiOutGetErrorTextW)(void);
    void (*midiOutGetID)(void);
    void (*midiOutGetNumDevs)(void);
    void (*midiOutGetVolume)(void);
    void (*midiOutLongMsg)(void);
    void (*midiOutMessage)(void);
    void (*midiOutOpen)(void);
    void (*midiOutPrepareHeader)(void);
    void (*midiOutReset)(void);
    void (*midiOutSetVolume)(void);
    void (*midiOutShortMsg)(void);
    void (*midiOutUnprepareHeader)(void);
    void (*midiStreamClose)(void);
    void (*midiStreamOpen)(void);
    void (*midiStreamOut)(void);
    void (*midiStreamPause)(void);
    void (*midiStreamPosition)(void);
    void (*midiStreamProperty)(void);
    void (*midiStreamRestart)(void);
    void (*midiStreamStop)(void);
    void (*mixerClose)(void);
    void (*mixerGetControlDetailsA)(void);
    void (*mixerGetControlDetailsW)(void);
    void (*mixerGetDevCapsA)(void);
    void (*mixerGetDevCapsW)(void);
    void (*mixerGetID)(void);
    void (*mixerGetLineControlsA)(void);
    void (*mixerGetLineControlsW)(void);
    void (*mixerGetLineInfoA)(void);
    void (*mixerGetLineInfoW)(void);
    void (*mixerGetNumDevs)(void);
    void (*mixerMessage)(void);
    void (*mixerOpen)(void);
    void (*mixerSetControlDetails)(void);
    void (*mmDrvInstall)(void);
    void (*mmGetCurrentTask)(void);
    void (*mmTaskBlock)(void);
    void (*mmTaskCreate)(void);
    void (*mmTaskSignal)(void);
    void (*mmTaskYield)(void);
    void (*mmioAdvance)(void);
    void (*mmioAscend)(void);
    void (*mmioClose)(void);
    void (*mmioCreateChunk)(void);
    void (*mmioDescend)(void);
    void (*mmioFlush)(void);
    void (*mmioGetInfo)(void);
    void (*mmioInstallIOProcA)(void);
    void (*mmioInstallIOProcW)(void);
    void (*mmioOpenA)(void);
    void (*mmioOpenW)(void);
    void (*mmioRead)(void);
    void (*mmioRenameA)(void);
    void (*mmioRenameW)(void);
    void (*mmioSeek)(void);
    void (*mmioSendMessage)(void);
    void (*mmioSetBuffer)(void);
    void (*mmioSetInfo)(void);
    void (*mmioStringToFOURCCA)(void);
    void (*mmioStringToFOURCCW)(void);
    void (*mmioWrite)(void);
    void (*mmsystemGetVersion)(void);
    void (*mod32Message)(void);
    void (*mxd32Message)(void);
    void (*sndPlaySoundA)(void);
    void (*sndPlaySoundW)(void);
    void (*tid32Message)(void);
    void (*timeBeginPeriod)(void);
    void (*timeEndPeriod)(void);
    void (*timeGetDevCaps)(void);
    void (*timeGetSystemTime)(void);
    void (*timeGetTime)(void);
    void (*timeKillEvent)(void);
    void (*timeSetEvent)(void);
//    void (*waveInAddBuffer)(void);
    UINT WINAPI (*waveInAddBuffer)(HWAVEIN, void*, UINT);
//    void (*waveInClose)(void);
    UINT WINAPI (*waveInClose)(HWAVEIN hwi);
    void (*waveInGetDevCapsA)(void);
    void (*waveInGetDevCapsW)(void);
    void (*waveInGetErrorTextA)(void);
    void (*waveInGetErrorTextW)(void);
    void (*waveInGetID)(void);
    void (*waveInGetNumDevs)(void);
    void (*waveInGetPosition)(void);
    void (*waveInMessage)(void);
//    void (*waveInOpen)(void);
    UINT WINAPI (*waveInOpen)(void*, UINT, void*, DWORD, DWORD, DWORD);
//    void (*waveInPrepareHeader)(void);
    UINT WINAPI (*waveInPrepareHeader)(HWAVEIN, void*, UINT);
//    void (*waveInReset)(void);
    UINT WINAPI (*waveInReset)(HWAVEIN);
//    void (*waveInStart)(void);
    UINT WINAPI (*waveInStart)(HWAVEIN);
//    void (*waveInStop)(void);
    UINT WINAPI (*waveInStop)(HWAVEIN);
//    void (*waveInUnprepareHeader)(void);
    UINT WINAPI (*waveInUnprepareHeader)(HWAVEIN, void*, UINT);
    void (*waveOutBreakLoop)(void);
    void (*waveOutClose)(void);
    void (*waveOutGetDevCapsA)(void);
    void (*waveOutGetDevCapsW)(void);
    void (*waveOutGetErrorTextA)(void);
    void (*waveOutGetErrorTextW)(void);
    void (*waveOutGetID)(void);
    void (*waveOutGetNumDevs)(void);
    void (*waveOutGetPitch)(void);
    void (*waveOutGetPlaybackRate)(void);
    void (*waveOutGetPosition)(void);
    void (*waveOutGetVolume)(void);
    void (*waveOutMessage)(void);
    void (*waveOutOpen)(void);
    void (*waveOutPause)(void);
    void (*waveOutPrepareHeader)(void);
    void (*waveOutReset)(void);
    void (*waveOutRestart)(void);
    void (*waveOutSetPitch)(void);
    void (*waveOutSetPlaybackRate)(void);
    void (*waveOutSetVolume)(void);
    void (*waveOutUnprepareHeader)(void);
    void (*waveOutWrite)(void);
    void (*wid32Message)(void);
    void (*winmmDbgOut)(void);
    void (*winmmSetDebugLevel)(void);
    void (*wod32Message)(void);
} winmm;

//---------------------------------------------------------------------------
static HWAVEIN       waveIn;         // WAVE OUT�n���h��
static WAVEFORMATEX  waveFmt;
static WAVEHDR      *waveBuf[2];      // WAVEHDR�\���̂ւ̃|�C���^
static volatile BOOL waveRecording;
static const int     waveBufSize = 1024;
static int Position[6];
//---------------------------------------------------------------------------

#ifdef JR_PCM
static void __fastcall ProcessPulse(int width, BOOL input)
{
    static int sync = 0;

    static unsigned int bitcount = 0;
    static unsigned int bitstream = 0;
    static int data[30];
    static int datacount = 0;

    if (sync == 0 && (int)floor(2.0 * width / PW_JR + 0.5) == 5) {
        sync = 1;
        bitstream = 0;
        bitcount = -1;
        datacount = 0;
        return;
    }

    if (!sync) return;

    width = (int)floor((double)width / PW_JR + 0.5);
    bitstream = ((bitstream << 1) + 1) << (width - 1);
    bitcount += width;

    if (bitcount >= 8) {
        bitcount -= 8;
        if ((data[datacount++] = jr_symbol[(bitstream >> bitcount) & 0xFF]) < 0) {
            sync = 0;
            return;
        }
    }

    switch (datacount) {
        case 3:  Position[2] = 1023 - ((data[1] << 5) | data[2]); break;
        case 6:  Position[0] = 1023 - ((data[4] << 5) | data[5]); break;
        case 11: Position[5] = 1023 - ((data[9] << 5) | data[10]); break;
        case 14: break;
        case 18: Position[3] = 1023 - ((data[16] << 5) | data[17]); break;
        case 21: Position[1] = 1023 - ((data[19] << 5) | data[20]); break;
        case 26: Position[4] = 1023 - ((data[24] << 5) | data[25]); break;
        case 28: break;
        case 30: sync = 0;
    }
}
#endif

//---------------------------------------------------------------------------

#ifdef FUTABA_PCM
static void __fastcall ProcessPulse(int width, BOOL input)
{
    static int sync = 0;

    static unsigned int bit = 0;
    static unsigned int bitcount = 0;
    static unsigned int bitstream = 0;

    static int data[32];
    static int datacount = 0;

    width = (int)floor(width / PW_FUTABA + 0.5);

    if (sync == 0 && width == 18) {
        sync = 1;
        bit = 0;
        bitstream = 0;
        bitcount = 0;
        datacount = 0;
        return;
    }

    if (!sync) return;

    bitstream = (bitstream << width) | (bit >> (32 - width));
    bit ^= 0xFFFFFFFF;
    bitcount += width;

    if (sync == 1) {
        if (bitcount >= 6) {
            bitcount -= 6;
            if (((bitstream >> bitcount) & 0x3F) == 0x03) {
                sync = 2;
                datacount = 0;
            } else if (((bitstream >> bitcount) & 0x3F) == 0x00) {
                sync = 2;
                datacount = 16;
                bitcount -= 2;
            } else {
                sync = 0;
            }
        }
        return;
    }

    if (bitcount >= 10) {
        bitcount -= 10;
        if ((data[datacount++] = futaba_symbol[(bitstream >> bitcount) & 0x3FF]) < 0) {
            sync = 0;
            return;
        }
    }

    switch (datacount) {
        case 3:  if ((data[0] >> 4) != 0)  Position[2] = (data[1] << 4) | (data[2] >> 2); break;
        case 7:                            Position[3] = (data[5] << 4) | (data[6] >> 2); break;
        case 11: if ((data[0] >> 4) != 0)  Position[4] = (data[9] << 4) | (data[10] >> 2); break;
        case 15: sync = 0;
        case 19:                           Position[1] = (data[17] << 4) | (data[18] >> 2); break;
        case 23: if ((data[16] >> 4) != 1) Position[0] = (data[21] << 4) | (data[22] >> 2); break;
        case 27:                           Position[5] = (data[25] << 4) | (data[26] >> 2); break;
        case 31: break;
        case 32: sync = 0;
    }
}
//---------------------------------------------------------------------------
#endif

#ifdef FUTABA_PPM
static void __fastcall ProcessPulse(int width, BOOL input)
{
    static int sync = 0;

    int newdata;
    static int data[14];
    static int datacount = 0;

    if (sync == 0 && width > PPM_TRIG) {
        sync = 1;
        datacount = 0;
    }

    if (!sync) return;

    newdata = (width - PPM_MIN) / (PPM_MAX - PPM_MIN) * 1024;
    if (newdata < 0) newdata = 0;
    else if (newdata > 1023) newdata = 1023;

    if (data[datacount] - newdata > 100) data[datacount] -= 100;
    else if (newdata - data[datacount] > 100) data[datacount] += 100;
    else data[datacount] = (data[datacount] + newdata) / 2;
    datacount++;

    switch (datacount) {
        case 3:  Position[2] = data[2]; break;
        case 5:  Position[1] = data[4]; break;
        case 7:  Position[3] = data[6]; break;
        case 9:  Position[0] = data[8]; break;
        case 11: Position[4] = data[10]; break;
        case 13: Position[5] = data[12]; sync = 0; break;
    }
}
#endif

#ifdef JR_PPM
static void __fastcall ProcessPulse(int width, BOOL input)
{
    static int sync = 0;

    int newdata;
    static int data[14];
    static int datacount = 0;

    if (sync == 0 && width > PPM_TRIG) {
        sync = 1;
        datacount = 0;
    }

    if (!sync) return;

    newdata = 1024 - (width - PPM_MIN) / (PPM_MAX - PPM_MIN) * 1024;
    if (newdata < 0) newdata = 0;
    else if (newdata > 1023) newdata = 1023;

    if (data[datacount] - newdata > 100) data[datacount] -= 100;
    else if (newdata - data[datacount] > 100) data[datacount] += 100;
    else data[datacount] = (data[datacount] + newdata) / 2;
    datacount++;

    switch (datacount) {
        case 3:  Position[3] = data[2]; break;
        case 5:  Position[2] = data[4]; break;
        case 7:  Position[1] = data[6]; break;
        case 9:  Position[0] = data[8]; break;
        case 11: Position[4] = data[10]; break;
        case 13: Position[5] = data[12]; sync = 0; break;
    }
}
#endif

static void __fastcall ProcessData(int i)
{
    static double min = 0;
    static double max = 0;
    static int high = 0;
    static int low = 0;
    double threshold;

//    max *= 0.9999;
//    min *= 0.9999;
    max -= 0.1;
    min += 0.1;
    if (max < min) max = min + 1;

    if (i> max) max = i;
    else if (i < min) min = i;
    threshold = (min + max) / 2;

    if (i > threshold) {
	high++;
        if (low) {
            ProcessPulse(low, FALSE);
            low = 0;
        }
    } else {
        low++;
        if (high) {
            ProcessPulse(high, TRUE);
            high = 0;
        }
    }
}
//---------------------------------------------------------------------------

static void CALLBACK waveInProc(HWAVEIN hwi, UINT uMsg, void *lpUser, WAVEHDR *buf, DWORD Reserved)
{
    int i;
    if (uMsg == WIM_DATA) {
        int Size = waveFmt.nBlockAlign;
        int Length = buf->dwBytesRecorded / Size;
        if (Size == 1) {
            for (i = 0; i < Length; i++) {
                ProcessData((unsigned char)buf->lpData[i]);
            }
        } else if (Size == 2) {
            for (i = 0; i < Length; i++) {
                ProcessData(((signed short*)(buf->lpData))[i]);
            }
        }
        if (waveRecording) (*(winmm.waveInAddBuffer))(waveIn, waveBuf[buf->dwUser], sizeof(WAVEHDR));
    }
}

//---------------------------------------------------------------------------

void StartPropo(void)
{
    int i;
    waveRecording = TRUE;
    waveFmt.wFormatTag = WAVE_FORMAT_PCM;
    waveFmt.nChannels = 1;
    waveFmt.nSamplesPerSec = 44100;
    waveFmt.wBitsPerSample =16;
    waveFmt.nBlockAlign = waveFmt.wBitsPerSample / 8 * waveFmt.nChannels;
    waveFmt.nAvgBytesPerSec = waveFmt.nSamplesPerSec * waveFmt.nBlockAlign;
    waveFmt.cbSize = 0;
    (*(winmm.waveInOpen))(&waveIn, WAVE_MAPPER, &waveFmt, (DWORD)(waveInProc), 0, CALLBACK_FUNCTION);
    for (i = 0; i < 2; i++) {
        waveBuf[i] = (WAVEHDR*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(WAVEHDR));
        waveBuf[i]->lpData = (char*)HeapAlloc(GetProcessHeap(), 0, waveBufSize);
        waveBuf[i]->dwBufferLength = waveBufSize;
        waveBuf[i]->dwUser = i;
        (*(winmm.waveInPrepareHeader))(waveIn, waveBuf[i], sizeof(WAVEHDR));
        (*(winmm.waveInAddBuffer))(waveIn, waveBuf[i], sizeof(WAVEHDR));
    }
    (*(winmm.waveInStart))(waveIn);
}
//---------------------------------------------------------------------------

void StopPropo(void)
{
    int i, s[2];

    waveRecording = FALSE;
    (*(winmm.waveInStop))(waveIn);
    for (i = 0; i < 2 ;i++) {
        (*(winmm.waveInUnprepareHeader))(waveIn, waveBuf[i], sizeof(WAVEHDR));
        HeapFree(GetProcessHeap(), 0, waveBuf[i]->lpData);
        HeapFree(GetProcessHeap(), 0, waveBuf[i]);
    }
    (*(winmm.waveInClose))(waveIn);
}

//---------------------------------------------------------------------------
int GetPosition(int ch)
{
    return Position[ch];
}
//---------------------------------------------------------------------------

typedef struct {
    WORD    wMid;                /* manufacturer ID */
    WORD    wPid;                /* product ID */
    CHAR    szPname[MAXPNAMELEN];/* product name (NULL terminated string) */
    UINT    wXmin;               /* minimum x position value */
    UINT    wXmax;               /* maximum x position value */
    UINT    wYmin;               /* minimum y position value */
    UINT    wYmax;               /* maximum y position value */
    UINT    wZmin;               /* minimum z position value */
    UINT    wZmax;               /* maximum z position value */
    UINT    wNumButtons;         /* number of buttons */
    UINT    wPeriodMin;          /* minimum message period when captured */
    UINT    wPeriodMax;          /* maximum message period when captured */
    UINT    wRmin;               /* minimum r position value */
    UINT    wRmax;               /* maximum r position value */
    UINT    wUmin;               /* minimum u (5th axis) position value */
    UINT    wUmax;               /* maximum u (5th axis) position value */
    UINT    wVmin;               /* minimum v (6th axis) position value */
    UINT    wVmax;               /* maximum v (6th axis) position value */
    UINT    wCaps;	 	 /* joystick capabilites */
    UINT    wMaxAxes;	 	 /* maximum number of axes supported */
    UINT    wNumAxes;	 	 /* number of axes in use */
    UINT    wMaxButtons;	 /* maximum number of buttons supported */
    CHAR    szRegKey[MAXPNAMELEN];/* registry key */
    CHAR    szOEMVxD[MAX_JOYSTICKOEMVXDNAME]; /* OEM VxD in use */
} *LPJOYCAPS;


typedef struct {
    UINT wXpos;                 /* x position */
    UINT wYpos;                 /* y position */
    UINT wZpos;                 /* z position */
    UINT wButtons;              /* button states */
} *LPJOYINFO;

typedef struct {
    DWORD dwSize;		 /* size of structure */
    DWORD dwFlags;		 /* flags to indicate what to return */
    DWORD dwXpos;                /* x position */
    DWORD dwYpos;                /* y position */
    DWORD dwZpos;                /* z position */
    DWORD dwRpos;		 /* rudder/4th axis position */
    DWORD dwUpos;		 /* 5th axis position */
    DWORD dwVpos;		 /* 6th axis position */
    DWORD dwButtons;             /* button states */
    DWORD dwButtonNumber;        /* current button number pressed */
    DWORD dwPOV;                 /* point of view state */
    DWORD dwReserved1;		 /* reserved for communication between winmm & driver */
    DWORD dwReserved2;		 /* reserved for future expansion */
} *LPJOYINFOEX;


extern __declspec(naked, dllexport) void WINAPI CloseDriver(void) { _asm{ jmp dword ptr winmm.CloseDriver;} }
extern __declspec(naked, dllexport) void WINAPI DefDriverProc(void) { _asm { jmp dword ptr winmm.DefDriverProc;} }
extern __declspec(naked, dllexport) void WINAPI DriverCallback(void) { _asm { jmp dword ptr winmm.DriverCallback;} }
extern __declspec(naked, dllexport) void WINAPI DrvGetModuleHandle(void) { _asm { jmp dword ptr winmm.DrvGetModuleHandle;} }
extern __declspec(naked, dllexport) void WINAPI GetDriverModuleHandle(void) { _asm { jmp dword ptr winmm.GetDriverModuleHandle;} }
extern __declspec(naked, dllexport) void WINAPI MigrateAllDrivers(void) { _asm { jmp dword ptr winmm.MigrateAllDrivers;} }
extern __declspec(naked, dllexport) void WINAPI MigrateMidiUser(void) { _asm { jmp dword ptr winmm.MigrateMidiUser;} }
extern __declspec(naked, dllexport) void WINAPI MigrateSoundEvents(void) { _asm { jmp dword ptr winmm.MigrateSoundEvents;} }
extern __declspec(naked, dllexport) void WINAPI NotifyCallbackData(void) { _asm { jmp dword ptr winmm.NotifyCallbackData;} }
extern __declspec(naked, dllexport) void WINAPI OpenDriver(void) { _asm { jmp dword ptr winmm.OpenDriver;} }
extern __declspec(naked, dllexport) void WINAPI PlaySound(void) { _asm { jmp dword ptr winmm.PlaySound;} }
extern __declspec(naked, dllexport) void WINAPI PlaySoundA(void) { _asm { jmp dword ptr winmm.PlaySoundA;} }
extern __declspec(naked, dllexport) void WINAPI PlaySoundW(void) { _asm { jmp dword ptr winmm.PlaySoundW;} }
extern __declspec(naked, dllexport) void WINAPI SendDriverMessage(void) { _asm { jmp dword ptr winmm.SendDriverMessage;} }
extern __declspec(naked, dllexport) void WINAPI WOW32DriverCallback(void) { _asm { jmp dword ptr winmm.WOW32DriverCallback;} }
extern __declspec(naked, dllexport) void WINAPI WOW32ResolveMultiMediaHandle(void) { _asm { jmp dword ptr winmm.WOW32ResolveMultiMediaHandle;} }
extern __declspec(naked, dllexport) void WINAPI WOWAppExit(void) { _asm { jmp dword ptr winmm.WOWAppExit;} }
extern __declspec(naked, dllexport) void WINAPI WinmmLogoff(void) { _asm { jmp dword ptr winmm.WinmmLogoff;} }
extern __declspec(naked, dllexport) void WINAPI WinmmLogon(void) { _asm { jmp dword ptr winmm.WinmmLogon;} }
extern __declspec(naked, dllexport) void WINAPI aux32Message(void) { _asm { jmp dword ptr winmm.aux32Message;} }
extern __declspec(naked, dllexport) void WINAPI auxGetDevCapsA(void) { _asm { jmp dword ptr winmm.auxGetDevCapsA;} }
extern __declspec(naked, dllexport) void WINAPI auxGetDevCapsW(void) { _asm { jmp dword ptr winmm.auxGetDevCapsW;} }
extern __declspec(naked, dllexport) void WINAPI auxGetNumDevs(void) { _asm { jmp dword ptr winmm.auxGetNumDevs;} }
extern __declspec(naked, dllexport) void WINAPI auxGetVolume(void) { _asm { jmp dword ptr winmm.auxGetVolume;} }
extern __declspec(naked, dllexport) void WINAPI auxOutMessage(void) { _asm { jmp dword ptr winmm.auxOutMessage;} }
extern __declspec(naked, dllexport) void WINAPI auxSetVolume(void) { _asm { jmp dword ptr winmm.auxSetVolume;} }
extern __declspec(naked, dllexport) void WINAPI joy32Message(void) { _asm { jmp dword ptr winmm.joy32Message;} }
extern __declspec(naked, dllexport) void WINAPI joyConfigChanged(void) { _asm { jmp dword ptr winmm.joyConfigChanged;} }

//extern __declspec(naked, dllexport) void WINAPI joyGetDevCapsA(void) { _asm { jmp dword ptr winmm.joyGetDevCapsA;} }
extern __declspec(dllexport) UINT WINAPI joyGetDevCapsA(UINT uJoyID, LPJOYCAPS pjc, UINT cbjc) {
    if (uJoyID == 0) {
        pjc->wMid = 0;
        pjc->wPid = 0;
        strcpy((char*)pjc->szPname, "SmartPropo");
        pjc->wXmin = pjc->wYmin = pjc->wZmin = pjc->wRmin = pjc->wUmin = pjc->wVmin = 0;
        pjc->wXmax = pjc->wYmax = pjc->wZmax = pjc->wRmax = pjc->wUmax = pjc->wVmax = 100;
        pjc->wNumButtons = pjc->wMaxButtons = 6;
        pjc->wMaxAxes = pjc->wNumAxes = 6;
        pjc->wPeriodMin = pjc->wPeriodMax = 0;
        pjc->wCaps = JOYCAPS_HASV;
        pjc->szRegKey[0] = 0;
        pjc->szOEMVxD[0] = 0;
        return JOYERR_NOERROR;
    }
    pjc->wMid = 0;
    pjc->wPid = 0;
    strcpy((char*)pjc->szPname, "");
    pjc->wXmin = pjc->wYmin = pjc->wZmin = pjc->wRmin = pjc->wUmin = pjc->wVmin = 0;
    pjc->wXmax = pjc->wYmax = pjc->wZmax = pjc->wRmax = pjc->wUmax = pjc->wVmax = 0;
    pjc->wNumButtons = pjc->wMaxButtons = 0;
    pjc->wMaxAxes = pjc->wNumAxes = 0;
    pjc->wPeriodMin = pjc->wPeriodMax = 0;
    pjc->wCaps = JOYCAPS_HASV;
    pjc->szRegKey[0] = 0;
    pjc->szOEMVxD[0] = 0;
    return JOYERR_UNPLUGGED;
}

extern __declspec(naked, dllexport) void WINAPI joyGetDevCapsW(void) { _asm { jmp dword ptr winmm.joyGetDevCapsW;} }

//extern __declspec(naked, dllexport) void WINAPI joyGetNumDevs(void) { _asm { jmp dword ptr winmm.joyGetNumDevs;} }
extern __declspec(dllexport) UINT WINAPI joyGetNumDevs(void)
{
    return 1;
}

//extern __declspec(naked, dllexport) void WINAPI joyGetPos(void) { _asm { jmp dword ptr winmm.joyGetPos;} }
extern __declspec(dllexport) UINT WINAPI joyGetPos(UINT uJoyID, LPJOYINFO pji) {
    if (uJoyID == 0) {
        pji->wXpos = Position[0];
        pji->wYpos = Position[1];
        pji->wZpos = Position[2];
        pji->wButtons = 0;
        return JOYERR_NOERROR;
    }
    return JOYERR_UNPLUGGED;
}
//extern __declspec(naked, dllexport) void WINAPI joyGetPosEx(void) { _asm { jmp dword ptr winmm.joyGetPosEx;} }
extern __declspec(dllexport) UINT WINAPI joyGetPosEx(UINT uJoyID, LPJOYINFOEX pji) {
    if (uJoyID == 0) {
        pji->dwXpos = Position[0];
        pji->dwYpos = Position[1];
        pji->dwZpos = Position[2];
        pji->dwRpos = Position[3];
        pji->dwUpos = Position[4];
        pji->dwVpos = Position[5];
        return JOYERR_NOERROR;
    }
    return JOYERR_UNPLUGGED;
}

extern __declspec(naked, dllexport) void WINAPI joyGetThreshold(void) { _asm { jmp dword ptr winmm.joyGetThreshold;} }
extern __declspec(naked, dllexport) void WINAPI joyReleaseCapture(void) { _asm { jmp dword ptr winmm.joyReleaseCapture;} }
extern __declspec(naked, dllexport) void WINAPI joySetCapture(void) { _asm { jmp dword ptr winmm.joySetCapture;} }
extern __declspec(naked, dllexport) void WINAPI joySetThreshold(void) { _asm { jmp dword ptr winmm.joySetThreshold;} }

extern __declspec(naked, dllexport) void WINAPI mci32Message(void) { _asm { jmp dword ptr winmm.mci32Message;} }
extern __declspec(naked, dllexport) void WINAPI mciDriverNotify(void) { _asm { jmp dword ptr winmm.mciDriverNotify;} }
extern __declspec(naked, dllexport) void WINAPI mciDriverYield(void) { _asm { jmp dword ptr winmm.mciDriverYield;} }
extern __declspec(naked, dllexport) void WINAPI mciExecute(void) { _asm { jmp dword ptr winmm.mciExecute;} }
extern __declspec(naked, dllexport) void WINAPI mciFreeCommandResource(void) { _asm { jmp dword ptr winmm.mciFreeCommandResource;} }
extern __declspec(naked, dllexport) void WINAPI mciGetCreatorTask(void) { _asm { jmp dword ptr winmm.mciGetCreatorTask;} }
extern __declspec(naked, dllexport) void WINAPI mciGetDeviceIDA(void) { _asm { jmp dword ptr winmm.mciGetDeviceIDA;} }
extern __declspec(naked, dllexport) void WINAPI mciGetDeviceIDFromElementIDA(void) { _asm { jmp dword ptr winmm.mciGetDeviceIDFromElementIDA;} }
extern __declspec(naked, dllexport) void WINAPI mciGetDeviceIDFromElementIDW(void) { _asm { jmp dword ptr winmm.mciGetDeviceIDFromElementIDW;} }
extern __declspec(naked, dllexport) void WINAPI mciGetDeviceIDW(void) { _asm { jmp dword ptr winmm.mciGetDeviceIDW;} }
extern __declspec(naked, dllexport) void WINAPI mciGetDriverData(void) { _asm { jmp dword ptr winmm.mciGetDriverData;} }
extern __declspec(naked, dllexport) void WINAPI mciGetErrorStringA(void) { _asm { jmp dword ptr winmm.mciGetErrorStringA;} }
extern __declspec(naked, dllexport) void WINAPI mciGetErrorStringW(void) { _asm { jmp dword ptr winmm.mciGetErrorStringW;} }
extern __declspec(naked, dllexport) void WINAPI mciGetYieldProc(void) { _asm { jmp dword ptr winmm.mciGetYieldProc;} }
extern __declspec(naked, dllexport) void WINAPI mciLoadCommandResource(void) { _asm { jmp dword ptr winmm.mciLoadCommandResource;} }
extern __declspec(naked, dllexport) void WINAPI mciSendCommandA(void) { _asm { jmp dword ptr winmm.mciSendCommandA;} }
extern __declspec(naked, dllexport) void WINAPI mciSendCommandW(void) { _asm { jmp dword ptr winmm.mciSendCommandW;} }
extern __declspec(naked, dllexport) void WINAPI mciSendStringA(void) { _asm { jmp dword ptr winmm.mciSendStringA;} }
extern __declspec(naked, dllexport) void WINAPI mciSendStringW(void) { _asm { jmp dword ptr winmm.mciSendStringW;} }
extern __declspec(naked, dllexport) void WINAPI mciSetDriverData(void) { _asm { jmp dword ptr winmm.mciSetDriverData;} }
extern __declspec(naked, dllexport) void WINAPI mciSetYieldProc(void) { _asm { jmp dword ptr winmm.mciSetYieldProc;} }
extern __declspec(naked, dllexport) void WINAPI mid32Message(void) { _asm { jmp dword ptr winmm.mid32Message;} }
extern __declspec(naked, dllexport) void WINAPI midiConnect(void) { _asm { jmp dword ptr winmm.midiConnect;} }
extern __declspec(naked, dllexport) void WINAPI midiDisconnect(void) { _asm { jmp dword ptr winmm.midiDisconnect;} }
extern __declspec(naked, dllexport) void WINAPI midiInAddBuffer(void) { _asm { jmp dword ptr winmm.midiInAddBuffer;} }
extern __declspec(naked, dllexport) void WINAPI midiInClose(void) { _asm { jmp dword ptr winmm.midiInClose;} }
extern __declspec(naked, dllexport) void WINAPI midiInGetDevCapsA(void) { _asm { jmp dword ptr winmm.midiInGetDevCapsA;} }
extern __declspec(naked, dllexport) void WINAPI midiInGetDevCapsW(void) { _asm { jmp dword ptr winmm.midiInGetDevCapsW;} }
extern __declspec(naked, dllexport) void WINAPI midiInGetErrorTextA(void) { _asm { jmp dword ptr winmm.midiInGetErrorTextA;} }
extern __declspec(naked, dllexport) void WINAPI midiInGetErrorTextW(void) { _asm { jmp dword ptr winmm.midiInGetErrorTextW;} }
extern __declspec(naked, dllexport) void WINAPI midiInGetID(void) { _asm { jmp dword ptr winmm.midiInGetID;} }
extern __declspec(naked, dllexport) void WINAPI midiInGetNumDevs(void) { _asm { jmp dword ptr winmm.midiInGetNumDevs;} }
extern __declspec(naked, dllexport) void WINAPI midiInMessage(void) { _asm { jmp dword ptr winmm.midiInMessage;} }
extern __declspec(naked, dllexport) void WINAPI midiInOpen(void) { _asm { jmp dword ptr winmm.midiInOpen;} }
extern __declspec(naked, dllexport) void WINAPI midiInPrepareHeader(void) { _asm { jmp dword ptr winmm.midiInPrepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI midiInReset(void) { _asm { jmp dword ptr winmm.midiInReset;} }
extern __declspec(naked, dllexport) void WINAPI midiInStart(void) { _asm { jmp dword ptr winmm.midiInStart;} }
extern __declspec(naked, dllexport) void WINAPI midiInStop(void) { _asm { jmp dword ptr winmm.midiInStop;} }
extern __declspec(naked, dllexport) void WINAPI midiInUnprepareHeader(void) { _asm { jmp dword ptr winmm.midiInUnprepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI midiOutCacheDrumPatches(void) { _asm { jmp dword ptr winmm.midiOutCacheDrumPatches;} }
extern __declspec(naked, dllexport) void WINAPI midiOutCachePatches(void) { _asm { jmp dword ptr winmm.midiOutCachePatches;} }
extern __declspec(naked, dllexport) void WINAPI midiOutClose(void) { _asm { jmp dword ptr winmm.midiOutClose;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetDevCapsA(void) { _asm { jmp dword ptr winmm.midiOutGetDevCapsA;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetDevCapsW(void) { _asm { jmp dword ptr winmm.midiOutGetDevCapsW;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetErrorTextA(void) { _asm { jmp dword ptr winmm.midiOutGetErrorTextA;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetErrorTextW(void) { _asm { jmp dword ptr winmm.midiOutGetErrorTextW;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetID(void) { _asm { jmp dword ptr winmm.midiOutGetID;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetNumDevs(void) { _asm { jmp dword ptr winmm.midiOutGetNumDevs;} }
extern __declspec(naked, dllexport) void WINAPI midiOutGetVolume(void) { _asm { jmp dword ptr winmm.midiOutGetVolume;} }
extern __declspec(naked, dllexport) void WINAPI midiOutLongMsg(void) { _asm { jmp dword ptr winmm.midiOutLongMsg;} }
extern __declspec(naked, dllexport) void WINAPI midiOutMessage(void) { _asm { jmp dword ptr winmm.midiOutMessage;} }
extern __declspec(naked, dllexport) void WINAPI midiOutOpen(void) { _asm { jmp dword ptr winmm.midiOutOpen;} }
extern __declspec(naked, dllexport) void WINAPI midiOutPrepareHeader(void) { _asm { jmp dword ptr winmm.midiOutPrepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI midiOutReset(void) { _asm { jmp dword ptr winmm.midiOutReset;} }
extern __declspec(naked, dllexport) void WINAPI midiOutSetVolume(void) { _asm { jmp dword ptr winmm.midiOutSetVolume;} }
extern __declspec(naked, dllexport) void WINAPI midiOutShortMsg(void) { _asm { jmp dword ptr winmm.midiOutShortMsg;} }
extern __declspec(naked, dllexport) void WINAPI midiOutUnprepareHeader(void) { _asm { jmp dword ptr winmm.midiOutUnprepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamClose(void) { _asm { jmp dword ptr winmm.midiStreamClose;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamOpen(void) { _asm { jmp dword ptr winmm.midiStreamOpen;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamOut(void) { _asm { jmp dword ptr winmm.midiStreamOut;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamPause(void) { _asm { jmp dword ptr winmm.midiStreamPause;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamPosition(void) { _asm { jmp dword ptr winmm.midiStreamPosition;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamProperty(void) { _asm { jmp dword ptr winmm.midiStreamProperty;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamRestart(void) { _asm { jmp dword ptr winmm.midiStreamRestart;} }
extern __declspec(naked, dllexport) void WINAPI midiStreamStop(void) { _asm { jmp dword ptr winmm.midiStreamStop;} }
extern __declspec(naked, dllexport) void WINAPI mixerClose(void) { _asm { jmp dword ptr winmm.mixerClose;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetControlDetailsA(void) { _asm { jmp dword ptr winmm.mixerGetControlDetailsA;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetControlDetailsW(void) { _asm { jmp dword ptr winmm.mixerGetControlDetailsW;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetDevCapsA(void) { _asm { jmp dword ptr winmm.mixerGetDevCapsA;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetDevCapsW(void) { _asm { jmp dword ptr winmm.mixerGetDevCapsW;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetID(void) { _asm { jmp dword ptr winmm.mixerGetID;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetLineControlsA(void) { _asm { jmp dword ptr winmm.mixerGetLineControlsA;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetLineControlsW(void) { _asm { jmp dword ptr winmm.mixerGetLineControlsW;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetLineInfoA(void) { _asm { jmp dword ptr winmm.mixerGetLineInfoA;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetLineInfoW(void) { _asm { jmp dword ptr winmm.mixerGetLineInfoW;} }
extern __declspec(naked, dllexport) void WINAPI mixerGetNumDevs(void) { _asm { jmp dword ptr winmm.mixerGetNumDevs;} }
extern __declspec(naked, dllexport) void WINAPI mixerMessage(void) { _asm { jmp dword ptr winmm.mixerMessage;} }
extern __declspec(naked, dllexport) void WINAPI mixerOpen(void) { _asm { jmp dword ptr winmm.mixerOpen;} }
extern __declspec(naked, dllexport) void WINAPI mixerSetControlDetails(void) { _asm { jmp dword ptr winmm.mixerSetControlDetails;} }
extern __declspec(naked, dllexport) void WINAPI mmDrvInstall(void) { _asm { jmp dword ptr winmm.mmDrvInstall;} }
extern __declspec(naked, dllexport) void WINAPI mmGetCurrentTask(void) { _asm { jmp dword ptr winmm.mmGetCurrentTask;} }
extern __declspec(naked, dllexport) void WINAPI mmTaskBlock(void) { _asm { jmp dword ptr winmm.mmTaskBlock;} }
extern __declspec(naked, dllexport) void WINAPI mmTaskCreate(void) { _asm { jmp dword ptr winmm.mmTaskCreate;} }
extern __declspec(naked, dllexport) void WINAPI mmTaskSignal(void) { _asm { jmp dword ptr winmm.mmTaskSignal;} }
extern __declspec(naked, dllexport) void WINAPI mmTaskYield(void) { _asm { jmp dword ptr winmm.mmTaskYield;} }
extern __declspec(naked, dllexport) void WINAPI mmioAdvance(void) { _asm { jmp dword ptr winmm.mmioAdvance;} }
extern __declspec(naked, dllexport) void WINAPI mmioAscend(void) { _asm { jmp dword ptr winmm.mmioAscend;} }
extern __declspec(naked, dllexport) void WINAPI mmioClose(void) { _asm { jmp dword ptr winmm.mmioClose;} }
extern __declspec(naked, dllexport) void WINAPI mmioCreateChunk(void) { _asm { jmp dword ptr winmm.mmioCreateChunk;} }
extern __declspec(naked, dllexport) void WINAPI mmioDescend(void) { _asm { jmp dword ptr winmm.mmioDescend;} }
extern __declspec(naked, dllexport) void WINAPI mmioFlush(void) { _asm { jmp dword ptr winmm.mmioFlush;} }
extern __declspec(naked, dllexport) void WINAPI mmioGetInfo(void) { _asm { jmp dword ptr winmm.mmioGetInfo;} }
extern __declspec(naked, dllexport) void WINAPI mmioInstallIOProcA(void) { _asm { jmp dword ptr winmm.mmioInstallIOProcA;} }
extern __declspec(naked, dllexport) void WINAPI mmioInstallIOProcW(void) { _asm { jmp dword ptr winmm.mmioInstallIOProcW;} }
extern __declspec(naked, dllexport) void WINAPI mmioOpenA(void) { _asm { jmp dword ptr winmm.mmioOpenA;} }
extern __declspec(naked, dllexport) void WINAPI mmioOpenW(void) { _asm { jmp dword ptr winmm.mmioOpenW;} }
extern __declspec(naked, dllexport) void WINAPI mmioRead(void) { _asm { jmp dword ptr winmm.mmioRead;} }
extern __declspec(naked, dllexport) void WINAPI mmioRenameA(void) { _asm { jmp dword ptr winmm.mmioRenameA;} }
extern __declspec(naked, dllexport) void WINAPI mmioRenameW(void) { _asm { jmp dword ptr winmm.mmioRenameW;} }
extern __declspec(naked, dllexport) void WINAPI mmioSeek(void) { _asm { jmp dword ptr winmm.mmioSeek;} }
extern __declspec(naked, dllexport) void WINAPI mmioSendMessage(void) { _asm { jmp dword ptr winmm.mmioSendMessage;} }
extern __declspec(naked, dllexport) void WINAPI mmioSetBuffer(void) { _asm { jmp dword ptr winmm.mmioSetBuffer;} }
extern __declspec(naked, dllexport) void WINAPI mmioSetInfo(void) { _asm { jmp dword ptr winmm.mmioSetInfo;} }
extern __declspec(naked, dllexport) void WINAPI mmioStringToFOURCCA(void) { _asm { jmp dword ptr winmm.mmioStringToFOURCCA;} }
extern __declspec(naked, dllexport) void WINAPI mmioStringToFOURCCW(void) { _asm { jmp dword ptr winmm.mmioStringToFOURCCW;} }
extern __declspec(naked, dllexport) void WINAPI mmioWrite(void) { _asm { jmp dword ptr winmm.mmioWrite;} }
extern __declspec(naked, dllexport) void WINAPI mmsystemGetVersion(void) { _asm { jmp dword ptr winmm.mmsystemGetVersion;} }
extern __declspec(naked, dllexport) void WINAPI mod32Message(void) { _asm { jmp dword ptr winmm.mod32Message;} }
extern __declspec(naked, dllexport) void WINAPI mxd32Message(void) { _asm { jmp dword ptr winmm.mxd32Message;} }
extern __declspec(naked, dllexport) void WINAPI sndPlaySoundA(void) { _asm { jmp dword ptr winmm.sndPlaySoundA;} }
extern __declspec(naked, dllexport) void WINAPI sndPlaySoundW(void) { _asm { jmp dword ptr winmm.sndPlaySoundW;} }
extern __declspec(naked, dllexport) void WINAPI tid32Message(void) { _asm { jmp dword ptr winmm.tid32Message;} }
extern __declspec(naked, dllexport) void WINAPI timeBeginPeriod(void) { _asm { jmp dword ptr winmm.timeBeginPeriod;} }
extern __declspec(naked, dllexport) void WINAPI timeEndPeriod(void) { _asm { jmp dword ptr winmm.timeEndPeriod;} }
extern __declspec(naked, dllexport) void WINAPI timeGetDevCaps(void) { _asm { jmp dword ptr winmm.timeGetDevCaps;} }
extern __declspec(naked, dllexport) void WINAPI timeGetSystemTime(void) { _asm { jmp dword ptr winmm.timeGetSystemTime;} }
extern __declspec(naked, dllexport) void WINAPI timeGetTime(void) { _asm { jmp dword ptr winmm.timeGetTime;} }
extern __declspec(naked, dllexport) void WINAPI timeKillEvent(void) { _asm { jmp dword ptr winmm.timeKillEvent;} }
extern __declspec(naked, dllexport) void WINAPI timeSetEvent(void) { _asm { jmp dword ptr winmm.timeSetEvent;} }
extern __declspec(naked, dllexport) void WINAPI waveInAddBuffer(void) { _asm { jmp dword ptr winmm.waveInAddBuffer;} }
extern __declspec(naked, dllexport) void WINAPI waveInClose(void) { _asm { jmp dword ptr winmm.waveInClose;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetDevCapsA(void) { _asm { jmp dword ptr winmm.waveInGetDevCapsA;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetDevCapsW(void) { _asm { jmp dword ptr winmm.waveInGetDevCapsW;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetErrorTextA(void) { _asm { jmp dword ptr winmm.waveInGetErrorTextA;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetErrorTextW(void) { _asm { jmp dword ptr winmm.waveInGetErrorTextW;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetID(void) { _asm { jmp dword ptr winmm.waveInGetID;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetNumDevs(void) { _asm { jmp dword ptr winmm.waveInGetNumDevs;} }
extern __declspec(naked, dllexport) void WINAPI waveInGetPosition(void) { _asm { jmp dword ptr winmm.waveInGetPosition;} }
extern __declspec(naked, dllexport) void WINAPI waveInMessage(void) { _asm { jmp dword ptr winmm.waveInMessage;} }
extern __declspec(naked, dllexport) void WINAPI waveInOpen(void) { _asm { jmp dword ptr winmm.waveInOpen;} }
extern __declspec(naked, dllexport) void WINAPI waveInPrepareHeader(void) { _asm { jmp dword ptr winmm.waveInPrepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI waveInReset(void) { _asm { jmp dword ptr winmm.waveInReset;} }
extern __declspec(naked, dllexport) void WINAPI waveInStart(void) { _asm { jmp dword ptr winmm.waveInStart;} }
extern __declspec(naked, dllexport) void WINAPI waveInStop(void) { _asm { jmp dword ptr winmm.waveInStop;} }
extern __declspec(naked, dllexport) void WINAPI waveInUnprepareHeader(void) { _asm { jmp dword ptr winmm.waveInUnprepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI waveOutBreakLoop(void) { _asm { jmp dword ptr winmm.waveOutBreakLoop;} }
extern __declspec(naked, dllexport) void WINAPI waveOutClose(void) { _asm { jmp dword ptr winmm.waveOutClose;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetDevCapsA(void) { _asm { jmp dword ptr winmm.waveOutGetDevCapsA;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetDevCapsW(void) { _asm { jmp dword ptr winmm.waveOutGetDevCapsW;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetErrorTextA(void) { _asm { jmp dword ptr winmm.waveOutGetErrorTextA;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetErrorTextW(void) { _asm { jmp dword ptr winmm.waveOutGetErrorTextW;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetID(void) { _asm { jmp dword ptr winmm.waveOutGetID;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetNumDevs(void) { _asm { jmp dword ptr winmm.waveOutGetNumDevs;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetPitch(void) { _asm { jmp dword ptr winmm.waveOutGetPitch;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetPlaybackRate(void) { _asm { jmp dword ptr winmm.waveOutGetPlaybackRate;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetPosition(void) { _asm { jmp dword ptr winmm.waveOutGetPosition;} }
extern __declspec(naked, dllexport) void WINAPI waveOutGetVolume(void) { _asm { jmp dword ptr winmm.waveOutGetVolume;} }
extern __declspec(naked, dllexport) void WINAPI waveOutMessage(void) { _asm { jmp dword ptr winmm.waveOutMessage;} }
extern __declspec(naked, dllexport) void WINAPI waveOutOpen(void) { _asm { jmp dword ptr winmm.waveOutOpen;} }
extern __declspec(naked, dllexport) void WINAPI waveOutPause(void) { _asm { jmp dword ptr winmm.waveOutPause;} }
extern __declspec(naked, dllexport) void WINAPI waveOutPrepareHeader(void) { _asm { jmp dword ptr winmm.waveOutPrepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI waveOutReset(void) { _asm { jmp dword ptr winmm.waveOutReset;} }
extern __declspec(naked, dllexport) void WINAPI waveOutRestart(void) { _asm { jmp dword ptr winmm.waveOutRestart;} }
extern __declspec(naked, dllexport) void WINAPI waveOutSetPitch(void) { _asm { jmp dword ptr winmm.waveOutSetPitch;} }
extern __declspec(naked, dllexport) void WINAPI waveOutSetPlaybackRate(void) { _asm { jmp dword ptr winmm.waveOutSetPlaybackRate;} }
extern __declspec(naked, dllexport) void WINAPI waveOutSetVolume(void) { _asm { jmp dword ptr winmm.waveOutSetVolume;} }
extern __declspec(naked, dllexport) void WINAPI waveOutUnprepareHeader(void) { _asm { jmp dword ptr winmm.waveOutUnprepareHeader;} }
extern __declspec(naked, dllexport) void WINAPI waveOutWrite(void) { _asm { jmp dword ptr winmm.waveOutWrite;} }
extern __declspec(naked, dllexport) void WINAPI wid32Message(void) { _asm { jmp dword ptr winmm.wid32Message;} }
extern __declspec(naked, dllexport) void WINAPI winmmDbgOut(void) { _asm { jmp dword ptr winmm.winmmDbgOut;} }
extern __declspec(naked, dllexport) void WINAPI winmmSetDebugLevel(void) { _asm { jmp dword ptr winmm.winmmSetDebugLevel;} }
extern __declspec(naked, dllexport) void WINAPI wod32Message(void) { _asm { jmp dword ptr winmm.wod32Message;} }

//---------------------------------------------------------------------------

BOOL LoadWinmm(void)
{
    if (!GetSystemDirectory(winmm.Path, MAX_PATH)) return FALSE;
    strcat(winmm.Path, "\\winmm.dll");
    winmm.Handle = LoadLibrary(winmm.Path);
    if (!winmm.Handle) return FALSE;

    winmm.CloseDriver = (void*)GetProcAddress(winmm.Handle, "CloseDriver");
    winmm.DefDriverProc = (void*)GetProcAddress(winmm.Handle, "DefDriverProc");
    winmm.DriverCallback = (void*)GetProcAddress(winmm.Handle, "DriverCallback");
    winmm.DrvGetModuleHandle = (void*)GetProcAddress(winmm.Handle, "DrvGetModuleHandle");
    winmm.GetDriverModuleHandle = (void*)GetProcAddress(winmm.Handle, "GetDriverModuleHandle");
    winmm.MigrateAllDrivers = (void*)GetProcAddress(winmm.Handle, "MigrateAllDrivers");
    winmm.MigrateMidiUser = (void*)GetProcAddress(winmm.Handle, "MigrateMidiUser");
    winmm.MigrateSoundEvents = (void*)GetProcAddress(winmm.Handle, "MigrateSoundEvents");
    winmm.NotifyCallbackData = (void*)GetProcAddress(winmm.Handle, "NotifyCallbackData");
    winmm.OpenDriver = (void*)GetProcAddress(winmm.Handle, "OpenDriver");
    winmm.PlaySound = (void*)GetProcAddress(winmm.Handle, "PlaySound");
    winmm.PlaySoundA = (void*)GetProcAddress(winmm.Handle, "PlaySoundA");
    winmm.PlaySoundW = (void*)GetProcAddress(winmm.Handle, "PlaySoundW");
    winmm.SendDriverMessage = (void*)GetProcAddress(winmm.Handle, "SendDriverMessage");
    winmm.WOW32DriverCallback = (void*)GetProcAddress(winmm.Handle, "WOW32DriverCallback");
    winmm.WOW32ResolveMultiMediaHandle = (void*)GetProcAddress(winmm.Handle, "WOW32ResolveMultiMediaHandle");
    winmm.WOWAppExit = (void*)GetProcAddress(winmm.Handle, "WOWAppExit");
    winmm.WinmmLogoff = (void*)GetProcAddress(winmm.Handle, "WinmmLogoff");
    winmm.WinmmLogon = (void*)GetProcAddress(winmm.Handle, "WinmmLogon");
    winmm.aux32Message = (void*)GetProcAddress(winmm.Handle, "aux32Message");
    winmm.auxGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "auxGetDevCapsA");
    winmm.auxGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "auxGetDevCapsW");
    winmm.auxGetNumDevs = (void*)GetProcAddress(winmm.Handle, "auxGetNumDevs");
    winmm.auxGetVolume = (void*)GetProcAddress(winmm.Handle, "auxGetVolume");
    winmm.auxOutMessage = (void*)GetProcAddress(winmm.Handle, "auxOutMessage");
    winmm.auxSetVolume = (void*)GetProcAddress(winmm.Handle, "auxSetVolume");
    winmm.joy32Message = (void*)GetProcAddress(winmm.Handle, "joy32Message");
    winmm.joyConfigChanged = (void*)GetProcAddress(winmm.Handle, "joyConfigChanged");
    winmm.joyGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "joyGetDevCapsA");
    winmm.joyGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "joyGetDevCapsW");
    winmm.joyGetNumDevs = (void*)GetProcAddress(winmm.Handle, "joyGetNumDevs");
    winmm.joyGetPos = (void*)GetProcAddress(winmm.Handle, "joyGetPos");
    winmm.joyGetPosEx = (void*)GetProcAddress(winmm.Handle, "joyGetPosEx");
    winmm.joyGetThreshold = (void*)GetProcAddress(winmm.Handle, "joyGetThreshold");
    winmm.joyReleaseCapture = (void*)GetProcAddress(winmm.Handle, "joyReleaseCapture");
    winmm.joySetCapture = (void*)GetProcAddress(winmm.Handle, "joySetCapture");
    winmm.joySetThreshold = (void*)GetProcAddress(winmm.Handle, "joySetThreshold");
    winmm.mci32Message = (void*)GetProcAddress(winmm.Handle, "mci32Message");
    winmm.mciDriverNotify = (void*)GetProcAddress(winmm.Handle, "mciDriverNotify");
    winmm.mciDriverYield = (void*)GetProcAddress(winmm.Handle, "mciDriverYield");
    winmm.mciExecute = (void*)GetProcAddress(winmm.Handle, "mciExecute");
    winmm.mciFreeCommandResource = (void*)GetProcAddress(winmm.Handle, "mciFreeCommandResource");
    winmm.mciGetCreatorTask = (void*)GetProcAddress(winmm.Handle, "mciGetCreatorTask");
    winmm.mciGetDeviceIDA = (void*)GetProcAddress(winmm.Handle, "mciGetDeviceIDA");
    winmm.mciGetDeviceIDFromElementIDA = (void*)GetProcAddress(winmm.Handle, "mciGetDeviceIDFromElementIDA");
    winmm.mciGetDeviceIDFromElementIDW = (void*)GetProcAddress(winmm.Handle, "mciGetDeviceIDFromElementIDW");
    winmm.mciGetDeviceIDW = (void*)GetProcAddress(winmm.Handle, "mciGetDeviceIDW");
    winmm.mciGetDriverData = (void*)GetProcAddress(winmm.Handle, "mciGetDriverData");
    winmm.mciGetErrorStringA = (void*)GetProcAddress(winmm.Handle, "mciGetErrorStringA");
    winmm.mciGetErrorStringW = (void*)GetProcAddress(winmm.Handle, "mciGetErrorStringW");
    winmm.mciGetYieldProc = (void*)GetProcAddress(winmm.Handle, "mciGetYieldProc");
    winmm.mciLoadCommandResource = (void*)GetProcAddress(winmm.Handle, "mciLoadCommandResource");
    winmm.mciSendCommandA = (void*)GetProcAddress(winmm.Handle, "mciSendCommandA");
    winmm.mciSendCommandW = (void*)GetProcAddress(winmm.Handle, "mciSendCommandW");
    winmm.mciSendStringA = (void*)GetProcAddress(winmm.Handle, "mciSendStringA");
    winmm.mciSendStringW = (void*)GetProcAddress(winmm.Handle, "mciSendStringW");
    winmm.mciSetDriverData = (void*)GetProcAddress(winmm.Handle, "mciSetDriverData");
    winmm.mciSetYieldProc = (void*)GetProcAddress(winmm.Handle, "mciSetYieldProc");
    winmm.mid32Message = (void*)GetProcAddress(winmm.Handle, "mid32Message");
    winmm.midiConnect = (void*)GetProcAddress(winmm.Handle, "midiConnect");
    winmm.midiDisconnect = (void*)GetProcAddress(winmm.Handle, "midiDisconnect");
    winmm.midiInAddBuffer = (void*)GetProcAddress(winmm.Handle, "midiInAddBuffer");
    winmm.midiInClose = (void*)GetProcAddress(winmm.Handle, "midiInClose");
    winmm.midiInGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "midiInGetDevCapsA");
    winmm.midiInGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "midiInGetDevCapsW");
    winmm.midiInGetErrorTextA = (void*)GetProcAddress(winmm.Handle, "midiInGetErrorTextA");
    winmm.midiInGetErrorTextW = (void*)GetProcAddress(winmm.Handle, "midiInGetErrorTextW");
    winmm.midiInGetID = (void*)GetProcAddress(winmm.Handle, "midiInGetID");
    winmm.midiInGetNumDevs = (void*)GetProcAddress(winmm.Handle, "midiInGetNumDevs");
    winmm.midiInMessage = (void*)GetProcAddress(winmm.Handle, "midiInMessage");
    winmm.midiInOpen = (void*)GetProcAddress(winmm.Handle, "midiInOpen");
    winmm.midiInPrepareHeader = (void*)GetProcAddress(winmm.Handle, "midiInPrepareHeader");
    winmm.midiInReset = (void*)GetProcAddress(winmm.Handle, "midiInReset");
    winmm.midiInStart = (void*)GetProcAddress(winmm.Handle, "midiInStart");
    winmm.midiInStop = (void*)GetProcAddress(winmm.Handle, "midiInStop");
    winmm.midiInUnprepareHeader = (void*)GetProcAddress(winmm.Handle, "midiInUnprepareHeader");
    winmm.midiOutCacheDrumPatches = (void*)GetProcAddress(winmm.Handle, "midiOutCacheDrumPatches");
    winmm.midiOutCachePatches = (void*)GetProcAddress(winmm.Handle, "midiOutCachePatches");
    winmm.midiOutClose = (void*)GetProcAddress(winmm.Handle, "midiOutClose");
    winmm.midiOutGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "midiOutGetDevCapsA");
    winmm.midiOutGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "midiOutGetDevCapsW");
    winmm.midiOutGetErrorTextA = (void*)GetProcAddress(winmm.Handle, "midiOutGetErrorTextA");
    winmm.midiOutGetErrorTextW = (void*)GetProcAddress(winmm.Handle, "midiOutGetErrorTextW");
    winmm.midiOutGetID = (void*)GetProcAddress(winmm.Handle, "midiOutGetID");
    winmm.midiOutGetNumDevs = (void*)GetProcAddress(winmm.Handle, "midiOutGetNumDevs");
    winmm.midiOutGetVolume = (void*)GetProcAddress(winmm.Handle, "midiOutGetVolume");
    winmm.midiOutLongMsg = (void*)GetProcAddress(winmm.Handle, "midiOutLongMsg");
    winmm.midiOutMessage = (void*)GetProcAddress(winmm.Handle, "midiOutMessage");
    winmm.midiOutOpen = (void*)GetProcAddress(winmm.Handle, "midiOutOpen");
    winmm.midiOutPrepareHeader = (void*)GetProcAddress(winmm.Handle, "midiOutPrepareHeader");
    winmm.midiOutReset = (void*)GetProcAddress(winmm.Handle, "midiOutReset");
    winmm.midiOutSetVolume = (void*)GetProcAddress(winmm.Handle, "midiOutSetVolume");
    winmm.midiOutShortMsg = (void*)GetProcAddress(winmm.Handle, "midiOutShortMsg");
    winmm.midiOutUnprepareHeader = (void*)GetProcAddress(winmm.Handle, "midiOutUnprepareHeader");
    winmm.midiStreamClose = (void*)GetProcAddress(winmm.Handle, "midiStreamClose");
    winmm.midiStreamOpen = (void*)GetProcAddress(winmm.Handle, "midiStreamOpen");
    winmm.midiStreamOut = (void*)GetProcAddress(winmm.Handle, "midiStreamOut");
    winmm.midiStreamPause = (void*)GetProcAddress(winmm.Handle, "midiStreamPause");
    winmm.midiStreamPosition = (void*)GetProcAddress(winmm.Handle, "midiStreamPosition");
    winmm.midiStreamProperty = (void*)GetProcAddress(winmm.Handle, "midiStreamProperty");
    winmm.midiStreamRestart = (void*)GetProcAddress(winmm.Handle, "midiStreamRestart");
    winmm.midiStreamStop = (void*)GetProcAddress(winmm.Handle, "midiStreamStop");
    winmm.mixerClose = (void*)GetProcAddress(winmm.Handle, "mixerClose");
    winmm.mixerGetControlDetailsA = (void*)GetProcAddress(winmm.Handle, "mixerGetControlDetailsA");
    winmm.mixerGetControlDetailsW = (void*)GetProcAddress(winmm.Handle, "mixerGetControlDetailsW");
    winmm.mixerGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "mixerGetDevCapsA");
    winmm.mixerGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "mixerGetDevCapsW");
    winmm.mixerGetID = (void*)GetProcAddress(winmm.Handle, "mixerGetID");
    winmm.mixerGetLineControlsA = (void*)GetProcAddress(winmm.Handle, "mixerGetLineControlsA");
    winmm.mixerGetLineControlsW = (void*)GetProcAddress(winmm.Handle, "mixerGetLineControlsW");
    winmm.mixerGetLineInfoA = (void*)GetProcAddress(winmm.Handle, "mixerGetLineInfoA");
    winmm.mixerGetLineInfoW = (void*)GetProcAddress(winmm.Handle, "mixerGetLineInfoW");
    winmm.mixerGetNumDevs = (void*)GetProcAddress(winmm.Handle, "mixerGetNumDevs");
    winmm.mixerMessage = (void*)GetProcAddress(winmm.Handle, "mixerMessage");
    winmm.mixerOpen = (void*)GetProcAddress(winmm.Handle, "mixerOpen");
    winmm.mixerSetControlDetails = (void*)GetProcAddress(winmm.Handle, "mixerSetControlDetails");
    winmm.mmDrvInstall = (void*)GetProcAddress(winmm.Handle, "mmDrvInstall");
    winmm.mmGetCurrentTask = (void*)GetProcAddress(winmm.Handle, "mmGetCurrentTask");
    winmm.mmTaskBlock = (void*)GetProcAddress(winmm.Handle, "mmTaskBlock");
    winmm.mmTaskCreate = (void*)GetProcAddress(winmm.Handle, "mmTaskCreate");
    winmm.mmTaskSignal = (void*)GetProcAddress(winmm.Handle, "mmTaskSignal");
    winmm.mmTaskYield = (void*)GetProcAddress(winmm.Handle, "mmTaskYield");
    winmm.mmioAdvance = (void*)GetProcAddress(winmm.Handle, "mmioAdvance");
    winmm.mmioAscend = (void*)GetProcAddress(winmm.Handle, "mmioAscend");
    winmm.mmioClose = (void*)GetProcAddress(winmm.Handle, "mmioClose");
    winmm.mmioCreateChunk = (void*)GetProcAddress(winmm.Handle, "mmioCreateChunk");
    winmm.mmioDescend = (void*)GetProcAddress(winmm.Handle, "mmioDescend");
    winmm.mmioFlush = (void*)GetProcAddress(winmm.Handle, "mmioFlush");
    winmm.mmioGetInfo = (void*)GetProcAddress(winmm.Handle, "mmioGetInfo");
    winmm.mmioInstallIOProcA = (void*)GetProcAddress(winmm.Handle, "mmioInstallIOProcA");
    winmm.mmioInstallIOProcW = (void*)GetProcAddress(winmm.Handle, "mmioInstallIOProcW");
    winmm.mmioOpenA = (void*)GetProcAddress(winmm.Handle, "mmioOpenA");
    winmm.mmioOpenW = (void*)GetProcAddress(winmm.Handle, "mmioOpenW");
    winmm.mmioRead = (void*)GetProcAddress(winmm.Handle, "mmioRead");
    winmm.mmioRenameA = (void*)GetProcAddress(winmm.Handle, "mmioRenameA");
    winmm.mmioRenameW = (void*)GetProcAddress(winmm.Handle, "mmioRenameW");
    winmm.mmioSeek = (void*)GetProcAddress(winmm.Handle, "mmioSeek");
    winmm.mmioSendMessage = (void*)GetProcAddress(winmm.Handle, "mmioSendMessage");
    winmm.mmioSetBuffer = (void*)GetProcAddress(winmm.Handle, "mmioSetBuffer");
    winmm.mmioSetInfo = (void*)GetProcAddress(winmm.Handle, "mmioSetInfo");
    winmm.mmioStringToFOURCCA = (void*)GetProcAddress(winmm.Handle, "mmioStringToFOURCCA");
    winmm.mmioStringToFOURCCW = (void*)GetProcAddress(winmm.Handle, "mmioStringToFOURCCW");
    winmm.mmioWrite = (void*)GetProcAddress(winmm.Handle, "mmioWrite");
    winmm.mmsystemGetVersion = (void*)GetProcAddress(winmm.Handle, "mmsystemGetVersion");
    winmm.mod32Message = (void*)GetProcAddress(winmm.Handle, "mod32Message");
    winmm.mxd32Message = (void*)GetProcAddress(winmm.Handle, "mxd32Message");
    winmm.sndPlaySoundA = (void*)GetProcAddress(winmm.Handle, "sndPlaySoundA");
    winmm.sndPlaySoundW = (void*)GetProcAddress(winmm.Handle, "sndPlaySoundW");
    winmm.tid32Message = (void*)GetProcAddress(winmm.Handle, "tid32Message");
    winmm.timeBeginPeriod = (void*)GetProcAddress(winmm.Handle, "timeBeginPeriod");
    winmm.timeEndPeriod = (void*)GetProcAddress(winmm.Handle, "timeEndPeriod");
    winmm.timeGetDevCaps = (void*)GetProcAddress(winmm.Handle, "timeGetDevCaps");
    winmm.timeGetSystemTime = (void*)GetProcAddress(winmm.Handle, "timeGetSystemTime");
    winmm.timeGetTime = (void*)GetProcAddress(winmm.Handle, "timeGetTime");
    winmm.timeKillEvent = (void*)GetProcAddress(winmm.Handle, "timeKillEvent");
    winmm.timeSetEvent = (void*)GetProcAddress(winmm.Handle, "timeSetEvent");
    winmm.waveInAddBuffer = (void*)GetProcAddress(winmm.Handle, "waveInAddBuffer");
    winmm.waveInClose = (void*)GetProcAddress(winmm.Handle, "waveInClose");
    winmm.waveInGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "waveInGetDevCapsA");
    winmm.waveInGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "waveInGetDevCapsW");
    winmm.waveInGetErrorTextA = (void*)GetProcAddress(winmm.Handle, "waveInGetErrorTextA");
    winmm.waveInGetErrorTextW = (void*)GetProcAddress(winmm.Handle, "waveInGetErrorTextW");
    winmm.waveInGetID = (void*)GetProcAddress(winmm.Handle, "waveInGetID");
    winmm.waveInGetNumDevs = (void*)GetProcAddress(winmm.Handle, "waveInGetNumDevs");
    winmm.waveInGetPosition = (void*)GetProcAddress(winmm.Handle, "waveInGetPosition");
    winmm.waveInMessage = (void*)GetProcAddress(winmm.Handle, "waveInMessage");
    winmm.waveInOpen = (void*)GetProcAddress(winmm.Handle, "waveInOpen");
    winmm.waveInPrepareHeader = (void*)GetProcAddress(winmm.Handle, "waveInPrepareHeader");
    winmm.waveInReset = (void*)GetProcAddress(winmm.Handle, "waveInReset");
    winmm.waveInStart = (void*)GetProcAddress(winmm.Handle, "waveInStart");
    winmm.waveInStop = (void*)GetProcAddress(winmm.Handle, "waveInStop");
    winmm.waveInUnprepareHeader = (void*)GetProcAddress(winmm.Handle, "waveInUnprepareHeader");
    winmm.waveOutBreakLoop = (void*)GetProcAddress(winmm.Handle, "waveOutBreakLoop");
    winmm.waveOutClose = (void*)GetProcAddress(winmm.Handle, "waveOutClose");
    winmm.waveOutGetDevCapsA = (void*)GetProcAddress(winmm.Handle, "waveOutGetDevCapsA");
    winmm.waveOutGetDevCapsW = (void*)GetProcAddress(winmm.Handle, "waveOutGetDevCapsW");
    winmm.waveOutGetErrorTextA = (void*)GetProcAddress(winmm.Handle, "waveOutGetErrorTextA");
    winmm.waveOutGetErrorTextW = (void*)GetProcAddress(winmm.Handle, "waveOutGetErrorTextW");
    winmm.waveOutGetID = (void*)GetProcAddress(winmm.Handle, "waveOutGetID");
    winmm.waveOutGetNumDevs = (void*)GetProcAddress(winmm.Handle, "waveOutGetNumDevs");
    winmm.waveOutGetPitch = (void*)GetProcAddress(winmm.Handle, "waveOutGetPitch");
    winmm.waveOutGetPlaybackRate = (void*)GetProcAddress(winmm.Handle, "waveOutGetPlaybackRate");
    winmm.waveOutGetPosition = (void*)GetProcAddress(winmm.Handle, "waveOutGetPosition");
    winmm.waveOutGetVolume = (void*)GetProcAddress(winmm.Handle, "waveOutGetVolume");
    winmm.waveOutMessage = (void*)GetProcAddress(winmm.Handle, "waveOutMessage");
    winmm.waveOutOpen = (void*)GetProcAddress(winmm.Handle, "waveOutOpen");
    winmm.waveOutPause = (void*)GetProcAddress(winmm.Handle, "waveOutPause");
    winmm.waveOutPrepareHeader = (void*)GetProcAddress(winmm.Handle, "waveOutPrepareHeader");
    winmm.waveOutReset = (void*)GetProcAddress(winmm.Handle, "waveOutReset");
    winmm.waveOutRestart = (void*)GetProcAddress(winmm.Handle, "waveOutRestart");
    winmm.waveOutSetPitch = (void*)GetProcAddress(winmm.Handle, "waveOutSetPitch");
    winmm.waveOutSetPlaybackRate = (void*)GetProcAddress(winmm.Handle, "waveOutSetPlaybackRate");
    winmm.waveOutSetVolume = (void*)GetProcAddress(winmm.Handle, "waveOutSetVolume");
    winmm.waveOutUnprepareHeader = (void*)GetProcAddress(winmm.Handle, "waveOutUnprepareHeader");
    winmm.waveOutWrite = (void*)GetProcAddress(winmm.Handle, "waveOutWrite");
    winmm.wid32Message = (void*)GetProcAddress(winmm.Handle, "wid32Message");
    winmm.winmmDbgOut = (void*)GetProcAddress(winmm.Handle, "winmmDbgOut");
    winmm.winmmSetDebugLevel = (void*)GetProcAddress(winmm.Handle, "winmmSetDebugLevel");
    winmm.wod32Message = (void*)GetProcAddress(winmm.Handle, "wod32Message");

    return TRUE;
}

//---------------------------------------------------------------------------

int WINAPI DllMain(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
    switch(reason){
        case DLL_PROCESS_ATTACH:
	    winmm.TlsIndex = TlsAlloc();
            LoadWinmm();
            TlsSetValue(winmm.TlsIndex, winmm.Handle);
            StartPropo();
            break;

        case DLL_THREAD_ATTACH:
            TlsSetValue(winmm.TlsIndex, LoadLibrary(winmm.Path));
            LoadWinmm();
            break;

        case DLL_THREAD_DETACH:
            FreeLibrary(TlsGetValue(winmm.TlsIndex));
            break;

        case DLL_PROCESS_DETACH:
            FreeLibrary(winmm.Handle);
            StopPropo();
            break;
    }
    return 1;
}
